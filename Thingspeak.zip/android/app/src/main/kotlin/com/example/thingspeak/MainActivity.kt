package com.example.thingspeak

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
